<?php
require_once('../model/AdminModel.php');

class AdminController {
    private $model;

    public function __construct() {
        $this->model = new AdminModel();
    }

    public function approveProduct($productId) {
        $this->model->approveProduct($productId);
        header('Location: ../view/admin.php');
    }

    public function blockUser($userId) {
        $this->model->blockUser($userId);
        header('Location: ../view/admin.php');
    }
}
?>
