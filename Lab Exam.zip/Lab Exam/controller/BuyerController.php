<?php
require_once('../model/BuyerModel.php');

class BuyerController {
    private $model;

    public function __construct() {
        $this->model = new BuyerModel();
    }

    public function getProducts() {
        return $this->model->getProducts();
    }
}
?>
