<?php
require_once('db.php');

class AdminModel {
    public function approveProduct($productId) {
    }
    public function blockUser($userId) {
    }
}
?>
