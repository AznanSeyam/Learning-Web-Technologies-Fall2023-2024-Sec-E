<?php
require_once('db.php');

class SellerModel {
    public function addProduct($productName, $price) {
        $sql = "INSERT INTO products (product_name, price) VALUES ('$productName', '$price')";
        $result = $conn->query($sql);
    }
}
?>
