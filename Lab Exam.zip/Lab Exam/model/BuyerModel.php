<?php
require_once('db.php');

class BuyerModel {
    public function getProducts() {
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);

        $products = array();
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }

        return $products;
    }
}
?>
