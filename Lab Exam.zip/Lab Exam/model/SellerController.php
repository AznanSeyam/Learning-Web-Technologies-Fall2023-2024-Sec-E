<?php
require_once('../model/SellerModel.php');

class SellerController {
    private $model;

    public function __construct() {
        $this->model = new SellerModel();
    }

    public function addProduct($productName, $price) {
        $this->model->addProduct($productName, $price);
        header('Location: ../view/seller.php');
    }
}
?>
