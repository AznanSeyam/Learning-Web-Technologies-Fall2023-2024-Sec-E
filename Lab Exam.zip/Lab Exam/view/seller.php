<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome to the Seller Dashboard</h1>

    <form action="../controllers/SellerController.php" method="post">
        <label for="productName">Product Name:</label>
        <input type="text" id="productName" name="productName" required>

        <label for="price">Price:</label>
        <input type="text" id="price" name="price" required>

        <input type="hidden" name="action" value="addProduct">
        <input type="submit" value="Add Product">
    </form>
</body>
</html>
