<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome to the Admin Panel</h1>
    <a href="../controllers/AdminController.php?action=approveProduct&productId=1">Approve Product 1</a>
    <a href="../controllers/AdminController.php?action=blockUser&userId=1">Block User 1</a>
</body>
</html>
