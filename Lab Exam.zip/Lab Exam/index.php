<?php
header('Location: view/admin.php');
?>
